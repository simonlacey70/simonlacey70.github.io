(() => {
  const video = document.getElementById('fishbowl-video');
  if (!video) return;
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  video.muted = true;
  const update = () => { if (reduced.matches) video.pause(); else video.play().catch(() => {}); };
  reduced.addEventListener('change', update);
  update();
})();
