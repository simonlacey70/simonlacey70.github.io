(() => {
  const video = document.getElementById('fishbowl-video');
  const button = document.querySelector('.portrait-playback');
  if (!video || !button) return;
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  video.muted = true;
  button.hidden = false;
  const update = () => { button.textContent = video.paused ? 'Play animation' : 'Pause animation'; };
  const play = () => video.play().catch(update);
  video.addEventListener('play', update);
  video.addEventListener('pause', update);
  button.addEventListener('click', () => video.paused ? play() : video.pause());
  reduced.addEventListener('change', () => { if (reduced.matches) video.pause(); });
  if (!reduced.matches) play();
  update();
})();
