(() => {
  const field = document.querySelector('#work-search');
  if (!field) return;
  const form = field.closest('form');
  const grid = document.querySelector('#work-results');
  const heading = document.querySelector('#work-heading');
  const status = document.querySelector('.search-status');
  const pagination = document.querySelector('.pagination');
  const clear = document.querySelector('.search-clear');
  const original = grid.innerHTML;
  const normalize = text => text.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const records = JSON.parse(document.querySelector('#search-data').textContent)
    .map(record => ({ ...record, text: normalize(record.text) }));
  let timer;
  function search() {
    clearTimeout(timer);
    const query = field.value.trim();
    clear.hidden = !query;
    pagination.hidden = !!query;
    status.hidden = !query;
    heading.textContent = query ? 'Search results' : 'Latest work';
    if (!query) { grid.innerHTML = original; return; }
    const terms = normalize(query).split(/\s+/);
    const matches = records.filter(record => terms.every(term => record.text.includes(term)));
    grid.innerHTML = matches.map(record => record.card).join('');
    status.textContent = matches.length
      ? `${matches.length} ${matches.length === 1 ? 'post' : 'posts'} found for “${query}”`
      : `No posts found for “${query}”. Try another keyword.`;
  }
  field.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(search, 150); });
  form.addEventListener('submit', event => { event.preventDefault(); search(); });
  clear.addEventListener('click', () => { field.value = ''; search(); field.focus(); });
  field.addEventListener('keydown', event => {
    if (event.key === 'Escape') { field.value = ''; search(); }
  });
})();
